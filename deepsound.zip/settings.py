"""Settings + playlist persistence (JSON in the app folder)."""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS_FILE = os.path.join(HERE, 'settings.json')
PLAYLIST_FILE = os.path.join(HERE, 'playlist.json')
STATS_FILE = os.path.join(HERE, 'stats.json')

DEFAULTS = {
    'volume': 0.8,
    'shuffle': False,
    'repeat': 'off',        # 'off' | 'one' | 'all'
    'libraries': [],        # folders auto-scanned on start
}


def _read_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:  # noqa: BLE001
        return None


def load_settings():
    data = _read_json(SETTINGS_FILE) or {}
    settings = dict(DEFAULTS)
    settings.update(data)
    return settings


def save_settings(settings):
    try:
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as fh:
            json.dump(settings, fh, ensure_ascii=False, indent=2)
    except Exception:  # noqa: BLE001
        pass


def load_playlist():
    return _read_json(PLAYLIST_FILE) or []


def save_playlist(tracks):
    try:
        with open(PLAYLIST_FILE, 'w', encoding='utf-8') as fh:
            json.dump(tracks, fh, ensure_ascii=False, indent=2)
    except Exception:  # noqa: BLE001
        pass


def load_stats():
    data = _read_json(STATS_FILE)
    if data and isinstance(data, dict):
        return data.get('tracks', {})
    return {}


def save_stats(tracks_stats):
    try:
        with open(STATS_FILE, 'w', encoding='utf-8') as fh:
            json.dump({'tracks': tracks_stats}, fh, ensure_ascii=False, indent=2)
    except Exception:  # noqa: BLE001
        pass
