' Create a desktop shortcut for DeepSound that uses the app icon.
Set sh = CreateObject("WScript.Shell")
desktop = sh.SpecialFolders("Desktop")
pythonw = "C:\Users\lroesele.IVV5NET\AppData\Local\Programs\Python\Python312\pythonw.exe"
app = "C:\Users\lroesele.IVV5NET\Claude_Code\aimp_clone\aimp.py"
folder = "C:\Users\lroesele.IVV5NET\Claude_Code\aimp_clone"

Set lnk = sh.CreateShortcut(desktop & "\DeepSound.lnk")
lnk.TargetPath = pythonw
lnk.Arguments = """" & app & """"
lnk.WorkingDirectory = folder
lnk.IconLocation = folder & "\app.ico,0"
lnk.Description = "DeepSound music player"
lnk.Save

MsgBox "DeepSound shortcut created on your desktop.", 64, "DeepSound"
