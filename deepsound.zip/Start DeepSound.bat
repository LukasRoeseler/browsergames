@echo off
rem DeepSound - console launcher (for debugging / viewing errors)
start "" "C:\Users\lroesele.IVV5NET\AppData\Local\Programs\Python\Python312\pythonw.exe" "C:\Users\lroesele.IVV5NET\Claude_Code\aimp_clone\aimp.py"
