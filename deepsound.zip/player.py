"""Low-resource streaming audio player built on PyAV (decode) + sounddevice (output).

Decodes MP3/FLAC/OGG/M4A/etc. on the fly (no full-file load into RAM) so long
tracks and audiobooks stay light. Playback runs in a separate callback thread so
the GUI never blocks.
"""
import threading
import time
from collections import deque

import av
import numpy as np
import sounddevice as sd


class AudioPlayer:
    def __init__(self, sample_rate=44100):
        self.sample_rate = sample_rate
        self.channels = 2

        self._cond = threading.Condition()
        self._chunks = deque()
        self._buffered = 0

        self._container = None
        self._astream = None
        self._resampler = None
        self._stream = None
        self._decoder_thread = None
        self._stop_flag = threading.Event()

        self._eof = False
        self._ended_sent = False
        self._consumed = 0
        self._paused = True
        self._volume = 1.0
        self._path = None
        self._started = False
        self._error = None

        self.on_track_end = None

    # ------------------------------------------------------------------ props
    @property
    def position(self):
        return self._consumed / self.sample_rate

    @property
    def duration(self):
        if self._container and self._container.duration:
            return self._container.duration / av.time_base
        return 0.0

    @property
    def volume(self):
        return self._volume

    @property
    def is_playing(self):
        return self._started and not self._paused

    @property
    def loaded(self):
        return self._path is not None

    def set_volume(self, v):
        self._volume = max(0.0, min(1.0, float(v)))

    # ---------------------------------------------------------------- control
    def load(self, path, start_pos=0.0):
        self._teardown()
        self._path = path
        self._open_and_seek(max(0.0, start_pos))
        self._consumed = int(max(0.0, start_pos) * self.sample_rate)
        self._start_decoder()
        self._resume_stream()
        self._started = True
        self._paused = False

    def play(self):
        if self._path is None:
            return
        self._resume_stream()
        self._paused = False

    def pause(self):
        self._paused = True
        self._pause_stream()

    def toggle(self):
        if self._paused:
            self.play()
        else:
            self.pause()

    def stop(self):
        self._paused = True
        self._pause_stream()
        self._reset_buffers()
        self._consumed = 0
        self._started = False

    def seek(self, seconds):
        if self._path is None:
            return
        seconds = max(0.0, float(seconds))
        self._teardown()
        self._open_and_seek(seconds)
        self._consumed = int(seconds * self.sample_rate)
        self._start_decoder()
        self._resume_stream()
        self._started = True
        self._paused = False

    def close(self):
        self._teardown()
        self._path = None
        self._started = False

    # ---------------------------------------------------------------- internal
    def _teardown(self):
        self._stop_flag.set()
        self._pause_stream()
        if self._decoder_thread is not None:
            with self._cond:
                self._cond.notify_all()
            self._decoder_thread.join(timeout=2.0)
            self._decoder_thread = None
        self._close_container()
        self._reset_buffers()
        self._stop_flag.clear()

    def _open_and_seek(self, seconds):
        self._container = av.open(self._path)
        self._astream = self._container.streams.audio[0]
        if seconds > 0:
            tb = self._astream.time_base
            if tb:
                target = int(seconds * (tb.denominator / tb.numerator))
            else:
                target = int(seconds * 1000000)
            self._container.seek(target, stream=self._astream, backward=True)
        self._resampler = av.AudioResampler(
            format='fltp', layout='stereo', rate=self.sample_rate)
        self._eof = False
        self._ended_sent = False

    def _reset_buffers(self):
        with self._cond:
            self._chunks.clear()
            self._buffered = 0
            self._cond.notify_all()

    def _start_decoder(self):
        self._decoder_thread = threading.Thread(
            target=self._decode_loop, daemon=True)
        self._decoder_thread.start()

    def _decode_loop(self):
        cap = self.sample_rate * 3
        try:
            for frame in self._container.decode(self._astream):
                if self._stop_flag.is_set():
                    break
                for rf in self._resampler.resample(frame):
                    if self._stop_flag.is_set():
                        break
                    chunk = self._frame_to_chunk(rf)
                    if chunk is None or chunk.size == 0:
                        continue
                    with self._cond:
                        while self._buffered >= cap and not self._stop_flag.is_set():
                            self._cond.wait(timeout=0.1)
                        if self._stop_flag.is_set():
                            break
                        self._chunks.append(chunk)
                        self._buffered += chunk.shape[0]
                        self._cond.notify()
            for rf in self._resampler.resample(None):
                chunk = self._frame_to_chunk(rf)
                if chunk is None or chunk.size == 0:
                    continue
                with self._cond:
                    self._chunks.append(chunk)
                    self._buffered += chunk.shape[0]
                    self._cond.notify()
            self._eof = True
        except Exception as exc:  # noqa: BLE001
            self._error = str(exc)
            self._eof = True

    @staticmethod
    def _frame_to_chunk(rf):
        arr = rf.to_ndarray()
        if arr.ndim == 1:
            arr = arr.reshape(1, -1)
        if arr.shape[0] == 1:
            arr = np.repeat(arr, 2, axis=0)
        return np.ascontiguousarray(arr.T.astype(np.float32))

    def _callback(self, outdata, frames, time_info, status):
        with self._cond:
            filled = 0
            while filled < frames:
                if not self._chunks:
                    break
                chunk = self._chunks[0]
                take = min(frames - filled, chunk.shape[0])
                outdata[filled:filled + take] = chunk[:take]
                filled += take
                self._buffered -= take
                if take == chunk.shape[0]:
                    self._chunks.popleft()
                else:
                    self._chunks[0] = chunk[take:]
            self._cond.notify()
        if filled:
            outdata[:filled] *= self._volume
        self._consumed += filled
        if filled < frames and self._eof and not self._ended_sent:
            self._ended_sent = True
            if self.on_track_end:
                self.on_track_end()

    def _start_stream(self):
        if self._stream is None:
            self._stream = sd.OutputStream(
                samplerate=self.sample_rate,
                channels=self.channels,
                dtype='float32',
                callback=self._callback,
            )

    def _resume_stream(self):
        try:
            self._start_stream()
            if self._stream is not None:
                self._stream.start()
        except Exception as exc:  # noqa: BLE001
            self._error = str(exc)

    def _pause_stream(self):
        if self._stream is not None:
            try:
                self._stream.stop()
            except Exception:  # noqa: BLE001
                pass

    def _close_container(self):
        if self._container is not None:
            try:
                self._container.close()
            except Exception:  # noqa: BLE001
                pass
            self._container = None
            self._astream = None
            self._resampler = None
