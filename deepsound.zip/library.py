"""Metadata scanning and library helpers (mutagen)."""
import os

import mutagen

AUDIO_EXTS = {'.mp3', '.wav', '.flac', '.ogg', '.m4a', '.aac',
              '.opus', '.wma', '.aiff', '.mp4', '.m4b'}


def scan_folder(folder, progress=None):
    """Recursively collect audio files in a folder into track dicts."""
    tracks = []
    if not folder or not os.path.isdir(folder):
        return tracks
    for root, _dirs, files in os.walk(folder):
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in AUDIO_EXTS:
                continue
            path = os.path.join(root, fname)
            tracks.append(read_meta(path))
            if progress:
                progress(len(tracks))
    return tracks


def read_meta(path):
    """Return a track dict (title/artist/album/duration) for an audio file."""
    title = artist = album = None
    duration = 0.0
    try:
        audio = mutagen.File(path, easy=True)
        if audio is not None:
            if audio.get('title'):
                title = audio['title'][0]
            if audio.get('artist'):
                artist = audio['artist'][0]
            if audio.get('album'):
                album = audio['album'][0]
            if getattr(audio, 'info', None) and audio.info.length:
                duration = float(audio.info.length)
    except Exception:  # noqa: BLE001
        pass
    if not title:
        title = os.path.splitext(os.path.basename(path))[0]
    if not artist:
        artist = 'Unknown Artist'
    if not album:
        album = ''
    # Many downloads have no tags; split "Artist - Title" from the filename.
    if artist == 'Unknown Artist' and ' - ' in title:
        parts = title.split(' - ', 1)
        if len(parts) == 2:
            artist, title = parts[0].strip(), parts[1].strip()
    return {'path': path, 'title': title, 'artist': artist,
            'album': album, 'duration': duration}


def read_art(path):
    """Return embedded album art bytes, or None."""
    try:
        f = mutagen.File(path)
    except Exception:  # noqa: BLE001
        return None
    if f is None:
        return None
    try:
        tags = getattr(f, 'tags', None)
        if tags is not None and hasattr(tags, 'getall'):
            for apic in tags.getall('APIC'):
                if apic.data:
                    return apic.data
        if getattr(f, 'pictures', None):
            return f.pictures[0].data
        if tags is not None and 'covr' in tags:
            return bytes(tags['covr'][0])
    except Exception:  # noqa: BLE001
        pass
    return None
