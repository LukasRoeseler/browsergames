"""Generate / refresh the DeepSound app icon (app.ico and icon.png).

Run `python icon.py` to rebuild manually. The app also calls ``ensure_fresh()``
at startup, so the icon stays in sync with any future design change: whenever
``icon.svg`` or this file is newer than the generated ``app.ico``, it is
rebuilt automatically. A desktop shortcut that points to ``app.ico`` will then
show the updated logo.
"""
import os

import numpy as np
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ICO = os.path.join(HERE, 'app.ico')
PNG = os.path.join(HERE, 'icon.png')
SVG = os.path.join(HERE, 'icon.svg')
SOURCES = [SVG, os.path.abspath(__file__)]
SIZES = [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]


def build():
    W = H = 512
    R = 116  # corner radius

    # background diagonal gradient (cyan -> blue -> indigo)
    xx, yy = np.meshgrid(np.arange(W), np.arange(H))
    t = (xx + yy) / (W + H - 2)
    c0 = np.array([34, 211, 238], float)     # #22d3ee
    c1 = np.array([58, 160, 255], float)     # #3aa0ff
    c2 = np.array([124, 108, 240], float)    # #7c6cf0
    mid = t < 0.5
    img = np.empty((H, W, 3), np.uint8)
    img[mid] = c0[None, None, :] * (1 - 2 * t[mid, None]) + c1[None, None, :] * (2 * t[mid, None])
    img[~mid] = c1[None, None, :] * (2 - 2 * t[~mid, None]) + c2[None, None, :] * (2 * t[~mid, None] - 1)

    # rounded mask
    mask = Image.new('L', (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, W - 1, H - 1], radius=R, fill=255)
    rgb = Image.fromarray(img)
    r, g, b = rgb.split()
    base = Image.merge('RGBA', (r, g, b, mask)).convert('RGBA')

    # glassy top sheen
    sheen = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sheen).rounded_rectangle([0, 0, W - 1, H - 1], radius=R,
                                            fill=(255, 255, 255, 56))
    smask = np.zeros((H, W), np.uint8)
    smask[:] = np.linspace(255, 0, H)[:, None]
    sheen.putalpha(Image.fromarray(
        (np.array(sheen.split()[3]) * (smask / 255)).astype(np.uint8)))
    base = Image.alpha_composite(base, sheen)

    # faint equalizer bars
    eq = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    ed = ImageDraw.Draw(eq)
    for x, y, w, h in [(118, 96, 30, 168), (168, 96, 30, 228),
                       (218, 96, 30, 276), (268, 96, 30, 228),
                       (318, 96, 30, 168)]:
        ed.rounded_rectangle([x, y, x + w, y + h], radius=w // 2,
                             fill=(255, 255, 255, 44))
    base = Image.alpha_composite(base, eq)

    # white play triangle (rounded corners via round-join stroke)
    play = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    pd = ImageDraw.Draw(play)
    pts = [(204, 158), (362, 256), (204, 354)]
    pd.polygon(pts, fill=(255, 255, 255, 255))
    pd.line(pts + [pts[0]], fill=(255, 255, 255, 255), width=34, joint='curve')
    base = Image.alpha_composite(base, play)

    base.save(PNG, 'PNG')
    base.save(ICO, 'ICO', sizes=SIZES)
    return ICO, PNG


def ensure_fresh():
    """Rebuild the icon if it's missing or the design source is newer."""
    if not os.path.exists(ICO) or not os.path.exists(PNG):
        build()
        return True
    srcs = [s for s in SOURCES if os.path.exists(s)]
    newest_src = max(os.path.getmtime(s) for s in srcs)
    newest_out = max(os.path.getmtime(ICO), os.path.getmtime(PNG))
    if newest_src > newest_out:
        build()
        return True
    return False


if __name__ == '__main__':
    print(build())
