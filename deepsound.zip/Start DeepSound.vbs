' DeepSound - launch without a console window (runs in the background).
Set shell = CreateObject("WScript.Shell")
pythonw = "C:\Users\lroesele.IVV5NET\AppData\Local\Programs\Python\Python312\pythonw.exe"
app = "C:\Users\lroesele.IVV5NET\Claude_Code\aimp_clone\aimp.py"
shell.Run """" & pythonw & """ """ & app & """", 0, False
