"""DeepSound — a lightweight desktop music player.

Drop-in replacement for aimp.py.

Requires the existing project modules:
    player.py:
        AudioPlayer with load, play, pause, stop, seek, set_volume, close;
        loaded, is_playing, position; and on_track_end callback.
        As in the original application, load() is expected to start playback.

    library.py:
        scan_folder(path), read_art(path)

    settings.py:
        load_settings(), save_settings(data)
        load_playlist(), save_playlist(data)
        load_stats(), save_stats(data)

External dependencies remain those of the original application:
    Pillow, mutagen, PyAV, sounddevice.
"""

import ctypes
import io
import math
import os
import queue
import random
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk
from tkinter import font as tkfont

from PIL import Image, ImageDraw, ImageOps, ImageTk

import library
import player as player_mod
import settings as settings_mod

try:
    import icon
except ImportError:
    icon = None


VERSION = "0.3"

BG = "#101119"
CARD = "#191c28"
CARD2 = "#222737"
CARD3 = "#30374b"
TEXT = "#f2f5fc"
MUTED = "#a0abc1"
DIM = "#738099"
ACCENT = "#36d6e7"
ACCENT2 = "#9786ff"
SELECTED = "#334666"
TRACK = "#151923"
PLAYING = "#153d48"
DANGER = "#ff8b99"

FONT = "Segoe UI"
POLL_MS = 100
MAX_UNDO = 50


def fmt_time(seconds):
    try:
        seconds = float(seconds)
        seconds = int(max(0, seconds)) if math.isfinite(seconds) else 0
    except (TypeError, ValueError, OverflowError):
        seconds = 0
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"


def number(value, default=0.0):
    try:
        value = float(value)
        return value if math.isfinite(value) else default
    except (TypeError, ValueError, OverflowError):
        return default


def clamp(value, low=0.0, high=1.0):
    return max(low, min(high, value))


def path_key(path):
    return os.path.normcase(os.path.abspath(os.path.expanduser(path)))


def load_safely(function, default):
    try:
        result = function()
        return default if result is None else result
    except Exception:
        return default


class Tooltip:
    """Delayed tooltip; all operations run on the Tk event thread."""

    def __init__(self, widget):
        self.widget = widget
        self.text = ""
        self.job = None
        self.window = None
        widget.bind("<Leave>", lambda event: self.hide(), add="+")
        widget.bind("<ButtonPress>", lambda event: self.hide(), add="+")

    def set(self, text):
        text = text or ""
        if self.text == text:
            return
        self.hide()
        self.text = text
        if text:
            self.job = self.widget.after(550, self._show)

    def _show(self):
        self.job = None
        if not self.text:
            return
        try:
            self.window = tk.Toplevel(self.widget)
            self.window.overrideredirect(True)
            self.window.attributes("-topmost", True)
            tk.Label(
                self.window,
                text=self.text,
                bg=CARD3,
                fg=TEXT,
                font=(FONT, 9),
                padx=9,
                pady=5,
            ).pack()
            self.window.update_idletasks()
            width = self.window.winfo_reqwidth()
            x = min(
                self.widget.winfo_pointerx() + 14,
                self.widget.winfo_screenwidth() - width - 8,
            )
            y = self.widget.winfo_pointery() + 20
            self.window.geometry(f"+{max(0, x)}+{max(0, y)}")
        except tk.TclError:
            self.window = None

    def hide(self):
        if self.job is not None:
            try:
                self.widget.after_cancel(self.job)
            except tk.TclError:
                pass
            self.job = None
        if self.window is not None:
            try:
                self.window.destroy()
            except tk.TclError:
                pass
            self.window = None
        self.text = ""


class MediaKeys:
    """Windows global media-key listener (play/pause, next, previous).

    Uses RegisterHotKey on a hidden message-only window so the keys work even
    when DeepSound does not have keyboard focus.
    """

    WM_HOTKEY = 0x0312
    MOD_NOREPEAT = 0x4000
    VK_MEDIA_PLAY_PAUSE = 0xB3
    VK_MEDIA_NEXT_TRACK = 0xB0
    VK_MEDIA_PREV_TRACK = 0xB1
    _ACTIONS = {
        VK_MEDIA_PLAY_PAUSE: "playpause",
        VK_MEDIA_NEXT_TRACK: "next",
        VK_MEDIA_PREV_TRACK: "prev",
    }

    def __init__(self, notify):
        self._notify = notify
        self._hwnd = None
        self._thread_id = None
        self._thread = None
        self._running = False

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="MediaKeys"
        )
        self._thread.start()

    def _run(self):
        try:
            from ctypes import wintypes
        except Exception:
            return
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        hwnd = user32.CreateWindowExW(
            0, "STATIC", "ds_mediakeys", 0, 0, 0, 0, 0,
            None, None, None, None,
        )
        if not hwnd:
            return
        self._hwnd = hwnd
        self._thread_id = kernel32.GetCurrentThreadId()
        for vk in self._ACTIONS:
            user32.RegisterHotKey(hwnd, vk, self.MOD_NOREPEAT, vk)
        msg = wintypes.MSG()
        while self._running and user32.GetMessageW(
            ctypes.byref(msg), None, 0, 0
        ) != 0:
            if msg.message == self.WM_HOTKEY:
                action = self._ACTIONS.get(msg.wParam)
                if action:
                    self._notify(action)
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        for vk in self._ACTIONS:
            user32.UnregisterHotKey(hwnd, vk)
        user32.DestroyWindow(hwnd)
        self._hwnd = None
        self._thread_id = None

    def stop(self):
        if not self._running:
            return
        self._running = False
        if self._thread_id:
            try:
                ctypes.windll.user32.PostThreadMessageW(
                    self._thread_id, 0x0012, 0, 0
                )
            except Exception:
                pass


class App:
    def __init__(self, root):
        self.root = root
        self._closed = False
        self.events = queue.Queue()
        self.player = player_mod.AudioPlayer()

        self.media_keys = None
        if sys.platform == "win32":
            self.media_keys = MediaKeys(self._on_media_key)
            self.media_keys.start()

        loaded_settings = load_safely(settings_mod.load_settings, {})
        self.settings = (
            loaded_settings if isinstance(loaded_settings, dict) else {}
        )
        loaded_stats = load_safely(settings_mod.load_stats, {})
        self.stats = loaded_stats if isinstance(loaded_stats, dict) else {}

        # Normalize potentially older/corrupted statistics.
        for path, entry in list(self.stats.items()):
            if not isinstance(entry, dict):
                del self.stats[path]
                continue
            entry["title"] = str(entry.get("title") or "")
            entry["artist"] = str(entry.get("artist") or "")
            entry["count"] = int(max(0, number(entry.get("count"))))
            entry["time"] = max(0.0, number(entry.get("time")))

        self.tracks = []
        self.current = -1
        self.current_path = None
        self.shuffle = bool(self.settings.get("shuffle", False))
        self.repeat = self.settings.get("repeat", "off")
        if self.repeat not in ("off", "all", "one"):
            self.repeat = "off"

        self.volume = clamp(number(self.settings.get("volume"), 0.8))
        self.muted = bool(self.settings.get("muted", False))
        self.player.set_volume(0.0 if self.muted else self.volume)

        self.undo_stack = []
        self.shuffle_bag = []
        self.history = []
        self.history_position = -1
        self.queue = []

        self.scan_token = 0
        self.art_token = 0
        self.play_token = 0
        self.scanning = False

        self.art_image = None
        self.art_photo = None
        self.art_photo_size = None
        self._circle_cache = {}

        self.seek_dragging = False
        self.volume_dragging = False
        self.seek_fraction = 0.0

        self.drag_index = None
        self.drag_indices = []
        self.drag_start_y = 0
        self.dragging = False
        self.collapse_selection = None
        self.selection_anchor = None
        self.visible_indices = []
        self.sort_column = None
        self.sort_descending = False

        self.poll_job = None
        self.search_job = None
        self.settings_job = None
        self.redraw_job = None
        self.status_job = None

        self.stats_dirty = False
        self.last_stats_save = time.monotonic()
        self.last_resume_save = time.monotonic()
        self.listen_clock = time.monotonic()
        self.listen_active = False
        self.last_playing_state = False
        self.downloading = False
        self._last_progress = 0.0

        self._build_ui()
        self._bind_keys()
        self._load_playlist()
        self._restore_resume()
        self._poll()

    # ---------------------------------------------------------------- UI

    def _build_ui(self):
        self.root.title(f"DeepSound · {VERSION}")
        self.root.configure(bg=BG)
        self.root.geometry(self._saved_geometry())
        self.root.minsize(480, 640)
        self._set_icon()

        self.title_font = tkfont.Font(
            root=self.root, family=FONT, size=17, weight="bold"
        )
        self.artist_font = tkfont.Font(
            root=self.root, family=FONT, size=11
        )

        self._setup_style()

        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", padx=20, pady=(14, 6))

        self.logo_font = tkfont.Font(
            root=self.root, family=FONT, size=17, weight="bold"
        )
        self.logo = tk.Canvas(
            header, bg=BG, height=52, highlightthickness=0
        )
        self.logo.pack(side="left")
        self._draw_logo()

        self._button(header, "+ Folder", self.import_folder).pack(
            side="right", padx=(0, 8)
        )

        menu_button = tk.Menubutton(
            header,
            text="Options ▾",
            bg=CARD2,
            fg=TEXT,
            activebackground=CARD3,
            activeforeground=TEXT,
            relief="flat",
            bd=0,
            padx=10,
            pady=5,
            font=(FONT, 9),
            cursor="hand2",
        )
        self.options_menu = self._menu(menu_button)
        self.options_menu.add_command(
            label="Import folder…",
            command=self.import_folder,
            accelerator="Ctrl+O",
        )
        self.options_menu.add_command(
            label="Rescan library folders",
            command=self.rescan_libraries,
        )
        self.options_menu.add_command(
            label="Add from URL…", command=self.add_from_url
        )
        self.options_menu.add_separator()
        self.options_menu.add_command(
            label="Undo playlist change",
            command=self.undo,
            accelerator="Ctrl+Z",
        )
        self.options_menu.add_command(
            label="Clear playlist",
            command=self.clear_playlist,
            accelerator="Ctrl+L",
        )
        self.options_menu.add_separator()
        self.options_menu.add_command(
            label="Statistics…", command=self.show_statistics
        )
        self.options_menu.add_command(
            label="Keyboard shortcuts…", command=self.show_shortcuts
        )
        menu_button.configure(menu=self.options_menu)
        menu_button.pack(side="right")

        self.canvas = tk.Canvas(
            self.root,
            bg=BG,
            height=318,
            bd=0,
            highlightthickness=0,
            takefocus=True,
        )
        self.canvas.pack(fill="x", padx=12)
        self.canvas.bind("<Configure>", self._schedule_redraw)
        self.canvas.bind("<Button-1>", self._canvas_press)
        self.canvas.bind("<B1-Motion>", self._canvas_motion)
        self.canvas.bind("<ButtonRelease-1>", self._canvas_release)
        self.canvas.bind("<Motion>", self._canvas_hover)
        self.tooltip = Tooltip(self.canvas)

        toolbar = tk.Frame(self.root, bg=BG)
        toolbar.pack(fill="x", padx=20, pady=(12, 8))

        tk.Label(
            toolbar,
            text="PLAYLIST",
            bg=BG,
            fg=MUTED,
            font=(FONT, 10, "bold"),
        ).pack(side="left")

        self.count_label = tk.Label(
            toolbar, text="", bg=BG, fg=DIM, font=(FONT, 9)
        )
        self.count_label.pack(side="left", padx=9)

        search_frame = tk.Frame(self.root, bg=CARD2)
        search_frame.pack(fill="x", padx=20, pady=(0, 9))

        tk.Label(
            search_frame,
            text="Search",
            bg=CARD2,
            fg=DIM,
            font=(FONT, 9),
        ).pack(side="left", padx=(10, 8))

        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(
            search_frame,
            textvariable=self.search_var,
            bg=CARD2,
            fg=TEXT,
            insertbackground=ACCENT,
            relief="flat",
            bd=0,
            font=(FONT, 10),
        )
        self.search_entry.pack(
            side="left", fill="x", expand=True, ipady=8
        )
        self.search_entry.bind("<Escape>", self._clear_search)
        self.search_var.trace_add("write", self._search_changed)

        self._button(
            search_frame, "×", lambda: self.search_var.set("")
        ).pack(side="right", padx=4)

        self.playlist_frame = tk.Frame(self.root, bg=TRACK)
        self.playlist_frame.pack(
            fill="both", expand=True, padx=20, pady=(0, 8)
        )

        self.tree = ttk.Treeview(
            self.playlist_frame,
            columns=("number", "title", "artist", "duration"),
            show="headings",
            selectmode="extended",
            style="Music.Treeview",
        )

        columns = (
            ("number", "#", 42, False, "center"),
            ("title", "Title", 260, True, "w"),
            ("artist", "Artist", 155, True, "w"),
            ("duration", "Time", 66, False, "e"),
        )
        for name, label, width, stretch, anchor in columns:
            self.tree.heading(
                name,
                text=label,
                command=lambda c=name: self.sort_playlist(c),
            )
            self.tree.column(
                name,
                width=width,
                minwidth=32 if name == "number" else 50,
                stretch=stretch,
                anchor=anchor,
            )

        self.tree.tag_configure("odd", background="#191e2a")
        self.tree.tag_configure(
            "playing", background=PLAYING, foreground=ACCENT
        )

        scrollbar = ttk.Scrollbar(
            self.playlist_frame,
            orient="vertical",
            command=self.tree.yview,
        )
        self.tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)

        self.empty_label = tk.Label(
            self.playlist_frame,
            text="Your playlist is empty.\n\nAdd a music folder to get started.",
            bg=TRACK,
            fg=MUTED,
            font=(FONT, 11),
            justify="center",
        )

        self.drop_line = tk.Frame(
            self.playlist_frame, bg=ACCENT, height=3
        )

        self.tree.bind("<Double-1>", self._double_click)
        self.tree.bind("<Return>", self._play_selected_event)
        self.tree.bind("<ButtonPress-1>", self._tree_press)
        self.tree.bind("<B1-Motion>", self._tree_motion)
        self.tree.bind("<ButtonRelease-1>", self._tree_release)
        self.tree.bind("<Button-3>", self._context_menu)

        self.context = self._menu(self.tree)
        self.context.add_command(
            label="Play", command=self.play_selected
        )
        self.context.add_command(
            label="Add to queue", command=self.add_to_queue
        )
        self.context.add_command(
            label="Edit details…", command=self.edit_track
        )
        self.context.add_command(
            label="Show in folder", command=self.reveal_selected
        )
        self.context.add_command(
            label="Copy file path", command=self.copy_selected_path
        )
        self.context.add_separator()
        self.context.add_command(
            label="Remove selected",
            command=self.remove_selected,
            accelerator="Delete",
        )
        self.context.add_command(
            label="Select all visible",
            command=self.select_all,
            accelerator="Ctrl+A",
        )

        self.download_frame = tk.Frame(self.root, bg=BG)
        self.download_bar = ttk.Progressbar(
            self.download_frame,
            orient="horizontal",
            mode="determinate",
            maximum=100,
            style="Music.Horizontal.TProgressbar",
        )
        self.download_label = tk.Label(
            self.download_frame, text="", bg=BG, fg=MUTED,
            font=(FONT, 9), anchor="w",
        )
        self.download_bar.pack(
            side="left", fill="x", expand=True, padx=(0, 10)
        )
        self.download_label.pack(side="right")

        footer = tk.Frame(self.root, bg=BG)
        footer.pack(
            side="bottom", fill="x", padx=20, pady=(0, 12),
            before=self.playlist_frame,
        )
        self.footer = footer

        self.status_label = tk.Label(
            footer,
            text="Ready",
            anchor="w",
            bg=BG,
            fg=DIM,
            font=(FONT, 9),
        )
        self.status_label.pack(side="left", fill="x", expand=True)

        self.duration_label = tk.Label(
            footer, text="", bg=BG, fg=DIM, font=(FONT, 9)
        )
        self.duration_label.pack(side="right")

        self.download_frame.pack_forget()

    def _saved_geometry(self):
        geometry = self.settings.get("geometry")
        if isinstance(geometry, str):
            # Save only dimensions, avoiding off-screen monitor coordinates.
            try:
                width, height = geometry.split("x", 1)
                width, height = int(width), int(height)
                width = min(
                    max(480, width),
                    max(480, self.root.winfo_screenwidth() - 40),
                )
                height = min(
                    max(640, height),
                    max(640, self.root.winfo_screenheight() - 80),
                )
                return f"{width}x{height}"
            except ValueError:
                pass
        return "640x840"

    def _button(self, parent, text, command):
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=CARD2,
            fg=TEXT,
            activebackground=CARD3,
            activeforeground=TEXT,
            relief="flat",
            bd=0,
            padx=11,
            pady=5,
            font=(FONT, 9),
            cursor="hand2",
            highlightthickness=0,
        )

    @staticmethod
    def _menu(parent):
        return tk.Menu(
            parent,
            tearoff=False,
            bg=CARD2,
            fg=TEXT,
            activebackground=SELECTED,
            activeforeground=TEXT,
            bd=0,
            font=(FONT, 10),
        )

    def _setup_style(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(
            "Music.Treeview",
            background=TRACK,
            fieldbackground=TRACK,
            foreground=TEXT,
            borderwidth=0,
            relief="flat",
            rowheight=31,
            font=(FONT, 10),
        )
        style.configure(
            "Music.Treeview.Heading",
            background=CARD2,
            foreground=MUTED,
            relief="flat",
            padding=(7, 8),
            font=(FONT, 9, "bold"),
        )
        style.map(
            "Music.Treeview",
            background=[("selected", SELECTED)],
            foreground=[("selected", TEXT)],
        )
        style.map(
            "Music.Treeview.Heading",
            background=[("active", CARD3)],
        )
        style.configure(
            "Vertical.TScrollbar",
            background=ACCENT,
            troughcolor=TRACK,
            borderwidth=0,
            arrowsize=12,
        )
        style.map(
            "Vertical.TScrollbar",
            background=[("active", ACCENT2)],
        )
        style.configure(
            "Music.Horizontal.TProgressbar",
            troughcolor=TRACK,
            background=ACCENT,
            bordercolor=TRACK,
            lightcolor=ACCENT,
            darkcolor=ACCENT,
            thickness=6,
        )

    def _set_icon(self):
        here = os.path.dirname(os.path.abspath(__file__))
        ico = os.path.join(here, "app.ico")
        try:
            with Image.open(os.path.join(here, "icon.png")) as image:
                self.window_icon = ImageTk.PhotoImage(image.copy())
            self.root.iconphoto(True, self.window_icon)
        except Exception:
            pass
        try:
            self.root.iconbitmap(default=ico)
        except Exception:
            pass
        # Tk's default feather can still win on the taskbar; set the native
        # big/small window icons explicitly once the window exists.
        if sys.platform == "win32":
            self.root.after(50, lambda: self._set_native_icon(ico))

    def _set_native_icon(self, ico):
        try:
            user32 = ctypes.windll.user32
            user32.LoadImageW.restype = ctypes.c_void_p
            hwnd = user32.GetParent(self.root.winfo_id()) or self.root.winfo_id()
            for kind, size in ((0, 16), (1, 32)):  # ICON_SMALL, ICON_BIG
                handle = user32.LoadImageW(
                    None, ico, 1, size, size, 0x10  # IMAGE_ICON, LR_LOADFROMFILE
                )
                if handle:
                    user32.SendMessageW(
                        hwnd, 0x0080, kind, ctypes.c_void_p(handle)
                    )
        except Exception:
            pass

    def _status(self, text, error=False, temporary=False):
        if self._closed:
            return
        if self.status_job is not None:
            self.root.after_cancel(self.status_job)
            self.status_job = None
        self.status_label.configure(
            text=text, fg=DANGER if error else DIM
        )
        if temporary:
            self.status_job = self.root.after(
                5000, lambda: self._status("Ready")
            )

    # ------------------------------------------------------- Player drawing

    def _draw_logo(self):
        c = self.logo
        c.delete("all")
        text = "DEEPSOUND"
        # Widening retro/arcade shadow: stacked blue layers, larger (wider)
        # and lower toward the bottom, then a bright face on top.
        layers = [
            (34, 23, "#0c2c50"),
            (30, 22, "#123b70"),
            (26, 21, "#174b8c"),
            (22, 20, "#1c5ea8"),
            (18, 19, "#2273c4"),
            (14, 18, "#2a8ce0"),
        ]
        width = tkfont.Font(
            root=self.root, family=FONT, size=23, weight="bold"
        ).measure(text) + 24
        c.configure(width=width)
        cx = width / 2
        for y, size, color in layers:
            font = tkfont.Font(
                root=self.root, family=FONT, size=size, weight="bold"
            )
            c.create_text(
                cx, y, text=text, anchor="center", fill=color, font=font
            )
        c.create_text(
            cx, 6, text=text, anchor="center",
            fill="#eaf6ff", font=self.logo_font,
        )

    def _schedule_redraw(self, event=None):
        if self._closed:
            return
        if self.redraw_job is not None:
            self.root.after_cancel(self.redraw_job)
        self.redraw_job = self.root.after(35, self._redraw)

    def _rounded(self, x0, y0, x1, y1, radius, **kwargs):
        radius = max(0, min(radius, (x1 - x0) / 2, (y1 - y0) / 2))
        points = [
            x0 + radius, y0,
            x1 - radius, y0,
            x1, y0,
            x1, y0 + radius,
            x1, y1 - radius,
            x1, y1,
            x1 - radius, y1,
            x0 + radius, y1,
            x0, y1,
            x0, y1 - radius,
            x0, y0 + radius,
            x0, y0,
        ]
        return self.canvas.create_polygon(
            points, smooth=True, splinesteps=24, **kwargs
        )

    @staticmethod
    def _fit_text(text, font, width):
        text = str(text or "")
        if width <= 0:
            return ""
        if font.measure(text) <= width:
            return text
        low, high = 0, len(text)
        while low < high:
            middle = (low + high + 1) // 2
            if font.measure(text[:middle] + "…") <= width:
                low = middle
            else:
                high = middle - 1
        return text[:low].rstrip() + "…"

    def _redraw(self):
        self.redraw_job = None
        if self._closed:
            return
        c = self.canvas
        width = max(440, c.winfo_width())
        c.delete("all")

        self._rounded(
            0, 0, width, 318, 22, fill=CARD, outline=""
        )

        art_size = 96
        art_x, art_y = 22, 22
        self._draw_art(art_x, art_y, art_size)

        text_x = art_x + art_size + 19
        available = width - text_x - 24

        track = self._current_track()
        title = track.get("title", "") if track else "Find your next favorite."
        artist = track.get("artist", "") if track else "Add a folder to start listening"

        c.create_text(
            text_x, 42,
            text=self._fit_text(title, self.title_font, available),
            anchor="nw", fill=TEXT, font=self.title_font,
        )
        c.create_text(
            text_x, 78,
            text=self._fit_text(artist or "Unknown artist", self.artist_font, available),
            anchor="nw", fill=MUTED, font=self.artist_font,
        )

        self.metrics = {
            "seek_x0": 26,
            "seek_x1": width - 26,
            "seek_y": 153,
            "volume_x0": 59,
            "volume_x1": min(188, width * 0.39),
            "volume_y": 286,
        }
        m = self.metrics

        c.create_line(
            m["seek_x0"], m["seek_y"],
            m["seek_x1"], m["seek_y"],
            fill=CARD3, width=5, capstyle="round",
        )
        c.create_line(
            m["seek_x0"], m["seek_y"],
            m["seek_x0"], m["seek_y"],
            fill=ACCENT, width=5, capstyle="round", tags="seek_fill",
        )
        c.create_image(
            0, 0, image=self._circle_photo(5, TEXT), tags="seek_thumb"
        )
        c.create_text(
            26, 173, anchor="w", fill=MUTED,
            font=(FONT, 9), tags="elapsed",
        )
        c.create_text(
            width - 26, 173, anchor="e", fill=MUTED,
            font=(FONT, 9), tags="total",
        )

        cy = 226
        spread = min(158, (width - 80) / 2)
        side = spread * 0.55
        self.controls = {
            "shuffle": (width / 2 - spread, cy, 19),
            "previous": (width / 2 - side, cy, 25),
            "play": (width / 2, cy, 34),
            "next": (width / 2 + side, cy, 25),
            "repeat": (width / 2 + spread, cy, 19),
            "mute": (34, m["volume_y"], 16),
        }

        for name in ("shuffle", "previous", "play", "next", "repeat"):
            x, y, radius = self.controls[name]
            active = (
                (name == "shuffle" and self.shuffle)
                or (name == "repeat" and self.repeat != "off")
            )
            c.create_image(
                x, y,
                image=self._circle_photo(
                    radius,
                    ACCENT if name == "play" else CARD2,
                    ACCENT if active else None,
                ),
            )
            color = "#10212b" if name == "play" else (
                ACCENT if active else TEXT
            )

            if name == "play":
                if self.player.is_playing:
                    for offset in (-8, 5):
                        c.create_rectangle(
                            x + offset, y - 11, x + offset + 4, y + 11,
                            fill=color, outline="",
                        )
                else:
                    c.create_polygon(
                        x - 7, y - 12, x + 13, y, x - 7, y + 12,
                        fill=color, outline="",
                    )
            elif name in ("previous", "next"):
                direction = -1 if name == "previous" else 1
                c.create_polygon(
                    x - direction * 6, y - 9,
                    x + direction * 7, y,
                    x - direction * 6, y + 9,
                    fill=color, outline="",
                )
                bar_x = x + direction * 10
                c.create_line(
                    bar_x, y - 9, bar_x, y + 9,
                    fill=color, width=3,
                )
            else:
                c.create_text(
                    x, y,
                    text="⇄" if name == "shuffle" else "↻",
                    fill=color, font=(FONT, 18),
                )
                if name == "repeat" and self.repeat == "one":
                    c.create_image(
                        x + 13.5, y + 12.5,
                        image=self._circle_photo(7.5, ACCENT),
                    )
                    c.create_text(
                        x + 13.5, y + 12.5, text="1",
                        fill=BG, font=(FONT, 8, "bold"),
                    )

        self._draw_speaker(34, m["volume_y"])
        c.create_line(
            m["volume_x0"], m["volume_y"],
            m["volume_x1"], m["volume_y"],
            fill=CARD3, width=4, capstyle="round",
        )
        c.create_line(
            0, 0, 0, 0, fill=ACCENT2, width=4,
            capstyle="round", tags="volume_fill",
        )
        c.create_text(
            m["volume_x1"] + 10, m["volume_y"],
            anchor="w", fill=MUTED, font=(FONT, 9),
            tags="volume_text",
        )

        repeat_text = {"off": "Repeat off", "all": "Repeat all", "one": "Repeat one"}
        c.create_text(
            width - 24, m["volume_y"],
            text=("Shuffle · " if self.shuffle else "") + repeat_text[self.repeat],
            anchor="e", fill=DIM, font=(FONT, 8),
        )

        self.last_playing_state = bool(self.player.is_playing)
        self._update_progress()
        self._update_volume()

    def _circle_photo(self, radius, fill, outline=None):
        key = (round(radius * 2), fill, outline)
        photo = self._circle_cache.get(key)
        if photo is not None:
            return photo
        scale = 4
        size = max(2, int(round(radius * 2)))
        big = size * scale
        image = Image.new("RGBA", (big, big), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        draw.ellipse((1, 1, big - 2, big - 2), fill=fill)
        if outline:
            draw.ellipse(
                (2, 2, big - 3, big - 3), outline=outline, width=scale
            )
        image = image.resize((size, size), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(image, master=self.root)
        self._circle_cache[key] = photo
        return photo

    def _draw_art(self, x, y, size):
        if self.art_image is not None:
            if self.art_photo is None or self.art_photo_size != size:
                fitted = ImageOps.fit(
                    self.art_image,
                    (size, size),
                    method=Image.Resampling.LANCZOS,
                )
                self.art_photo = ImageTk.PhotoImage(fitted, master=self.root)
                self.art_photo_size = size
            self.canvas.create_image(
                x + size / 2, y + size / 2, image=self.art_photo
            )
        else:
            self._rounded(
                x, y, x + size, y + size, 16,
                fill=CARD2, outline=CARD3,
            )
            self.canvas.create_oval(
                x + 17, y + 17, x + size - 17, y + size - 17,
                outline="#46516d", width=2,
            )
            self.canvas.create_text(
                x + size / 2, y + size / 2,
                text="♪", fill=ACCENT2, font=(FONT, 35),
            )

    def _draw_speaker(self, x, y):
        c = self.canvas
        color = DIM if self.muted else MUTED
        c.create_polygon(
            x - 8, y - 4, x - 3, y - 4,
            x + 3, y - 9, x + 3, y + 9,
            x - 3, y + 4, x - 8, y + 4,
            fill=color, outline="",
        )
        if self.muted or self.volume == 0:
            c.create_line(
                x + 7, y - 4, x + 13, y + 4, fill=DANGER, width=2
            )
            c.create_line(
                x + 7, y + 4, x + 13, y - 4, fill=DANGER, width=2
            )
        else:
            c.create_arc(
                x - 4, y - 10, x + 13, y + 10,
                start=-55, extent=110, style="arc",
                outline=color, width=2,
            )

    def _update_progress(self):
        if not hasattr(self, "metrics"):
            return
        duration = self._duration()
        position = self._position() if self.current >= 0 else 0.0

        if not self.seek_dragging:
            self.seek_fraction = clamp(position / duration) if duration else 0.0

        m = self.metrics
        x = m["seek_x0"] + self.seek_fraction * (
            m["seek_x1"] - m["seek_x0"]
        )
        y = m["seek_y"]
        self.canvas.coords("seek_fill", m["seek_x0"], y, x, y)
        self.canvas.coords("seek_thumb", x, y)
        shown_position = (
            self.seek_fraction * duration if self.seek_dragging else position
        )
        self.canvas.itemconfigure("elapsed", text=fmt_time(shown_position))
        self.canvas.itemconfigure("total", text=fmt_time(duration))

    def _update_volume(self):
        if not hasattr(self, "metrics"):
            return
        m = self.metrics
        fraction = 0.0 if self.muted else self.volume
        x = m["volume_x0"] + fraction * (
            m["volume_x1"] - m["volume_x0"]
        )
        self.canvas.coords(
            "volume_fill",
            m["volume_x0"], m["volume_y"], x, m["volume_y"],
        )
        self.canvas.itemconfigure(
            "volume_text",
            text="Muted" if self.muted else f"{round(self.volume * 100)}%",
        )

    # -------------------------------------------------------- Canvas input

    def _hit_control(self, x, y):
        for name, (cx, cy, radius) in getattr(self, "controls", {}).items():
            if (x - cx) ** 2 + (y - cy) ** 2 <= (radius + 4) ** 2:
                return name
        return None

    def _canvas_press(self, event):
        self.canvas.focus_set()
        self.tooltip.hide()
        if not hasattr(self, "metrics"):
            return

        m = self.metrics
        if (
            abs(event.y - m["seek_y"]) <= 13
            and m["seek_x0"] <= event.x <= m["seek_x1"]
        ):
            if self.current >= 0 and self.player.loaded and self._duration() > 0:
                self.seek_dragging = True
                self._seek_from_x(event.x)
            return

        if (
            abs(event.y - m["volume_y"]) <= 12
            and m["volume_x0"] <= event.x <= m["volume_x1"]
        ):
            self.volume_dragging = True
            self._volume_from_x(event.x)
            return

        action = self._hit_control(event.x, event.y)
        actions = {
            "play": self.toggle_play,
            "previous": self.previous_track,
            "next": self.next_track,
            "shuffle": self.toggle_shuffle,
            "repeat": self.toggle_repeat,
            "mute": self.toggle_mute,
        }
        if action in actions:
            actions[action]()

    def _canvas_motion(self, event):
        if self.seek_dragging:
            self._seek_from_x(event.x)
        elif self.volume_dragging:
            self._volume_from_x(event.x)

    def _canvas_release(self, event):
        if self.seek_dragging:
            position = self.seek_fraction * self._duration()
            self.seek_dragging = False
            self.seek_to(position)
        self.volume_dragging = False

    def _canvas_hover(self, event):
        if not hasattr(self, "metrics"):
            return
        action = self._hit_control(event.x, event.y)
        labels = {
            "play": "Play / pause · Space",
            "previous": "Previous / restart · Ctrl+Left",
            "next": "Next · Ctrl+Right",
            "shuffle": "Toggle shuffle · Ctrl+S",
            "repeat": "Cycle repeat mode · Ctrl+R",
            "mute": "Mute / unmute · Ctrl+M",
        }
        text = labels.get(action, "")
        m = self.metrics
        if (
            abs(event.y - m["seek_y"]) <= 13
            and m["seek_x0"] <= event.x <= m["seek_x1"]
        ):
            fraction = clamp(
                (event.x - m["seek_x0"]) / (m["seek_x1"] - m["seek_x0"])
            )
            text = f"Seek to {fmt_time(fraction * self._duration())}"
        elif (
            abs(event.y - m["volume_y"]) <= 12
            and m["volume_x0"] <= event.x <= m["volume_x1"]
        ):
            text = "Volume · Ctrl+Up / Ctrl+Down"
        self.canvas.configure(cursor="hand2" if text else "")
        self.tooltip.set(text)

    def _seek_from_x(self, x):
        m = self.metrics
        self.seek_fraction = clamp(
            (x - m["seek_x0"]) / (m["seek_x1"] - m["seek_x0"])
        )
        self._update_progress()

    def _volume_from_x(self, x):
        m = self.metrics
        self.set_volume(
            (x - m["volume_x0"]) / (m["volume_x1"] - m["volume_x0"])
        )

    # ------------------------------------------------------------- Shortcuts

    def _on_media_key(self, action):
        if self._closed:
            return
        self.events.put(("media", action))

    def _handle_media_key(self, action):
        handlers = {
            "playpause": self.toggle_play,
            "next": self.next_track,
            "prev": self.previous_track,
        }
        handler = handlers.get(action)
        if handler:
            handler()

    def _bind_keys(self):
        def bind(sequence, callback, allow_entry=False):
            def handler(event):
                if not allow_entry and self._editing_text():
                    return None
                callback()
                return "break"

            self.root.bind(sequence, handler)

        bind("<space>", self.toggle_play)
        bind("<Control-Right>", self.next_track)
        bind("<Control-Left>", self.previous_track)
        bind("<Control-Up>", lambda: self.set_volume(self.volume + 0.05))
        bind("<Control-Down>", lambda: self.set_volume(self.volume - 0.05))
        bind("<Left>", lambda: self.seek_relative(-5))
        bind("<Right>", lambda: self.seek_relative(5))
        bind("<Control-m>", self.toggle_mute)
        bind("<Control-s>", self.toggle_shuffle)
        bind("<Control-r>", self.toggle_repeat)
        bind("<Control-o>", self.import_folder, True)
        bind("<Control-l>", self.clear_playlist)
        bind("<Control-z>", self.undo)
        bind("<Control-a>", self.select_all)
        bind("<Control-f>", self.focus_search, True)
        bind("<Delete>", self.remove_selected)
        bind("<Escape>", self._escape)

    def _editing_text(self):
        return isinstance(self.root.focus_get(), (tk.Entry, ttk.Entry, tk.Text))

    def _escape(self):
        if self.dragging:
            self._reset_drag()
            return
        if self.search_var.get():
            self.search_var.set("")
        self.tree.focus_set()

    def focus_search(self):
        self.search_entry.focus_set()
        self.search_entry.selection_range(0, "end")

    def _clear_search(self, event=None):
        self.search_var.set("")
        self.tree.focus_set()
        return "break"

    def show_shortcuts(self):
        messagebox.showinfo(
            "Keyboard shortcuts",
            "Space                 Play / pause\n"
            "Ctrl+Right            Next track\n"
            "Ctrl+Left             Previous / restart\n"
            "Left / Right          Seek backward / forward 5 seconds\n"
            "Ctrl+Up / Down        Adjust volume\n"
            "Ctrl+M                Mute / unmute\n"
            "Ctrl+S                Toggle shuffle\n"
            "Ctrl+R                Cycle repeat mode\n"
            "Ctrl+F                Search playlist\n"
            "Ctrl+O                Import folder\n"
            "Ctrl+A                Select all visible tracks\n"
            "Delete                Remove selected tracks\n"
            "Ctrl+Z                Undo playlist change\n"
            "Ctrl+L                Clear playlist\n"
            "Enter                 Play focused/selected track\n"
            "Escape                Clear search / cancel drag\n"
            "Media keys            Play/pause, next, previous\n\n"
            "Click a column heading to sort.\n"
            "Drag selected tracks to reorder; clear search first.",
            parent=self.root,
        )

    # ------------------------------------------------------ Playlist loading

    @staticmethod
    def _normalize_tracks(tracks):
        result = []
        seen = set()
        if not isinstance(tracks, (list, tuple)):
            return result

        for track in tracks:
            if not isinstance(track, dict):
                continue
            path = track.get("path")
            if not isinstance(path, str) or not path.strip():
                continue
            path = os.path.abspath(os.path.expanduser(path))
            key = path_key(path)
            if key in seen:
                continue
            seen.add(key)

            normalized = dict(track)
            normalized["path"] = path
            normalized["title"] = str(
                track.get("title") or os.path.splitext(os.path.basename(path))[0]
            )
            normalized["artist"] = str(track.get("artist") or "")
            normalized["duration"] = max(
                0.0, number(track.get("duration"))
            )
            result.append(normalized)
        return result

    def _load_playlist(self):
        saved = load_safely(settings_mod.load_playlist, [])
        self.tracks = self._normalize_tracks(saved)
        self._refresh_tree()
        self._reset_shuffle_bag()

        # Preserve intentionally empty playlists on subsequent launches.
        if not self.tracks and not self.settings.get("playlist_initialized"):
            folders = self.settings.get("libraries", [])
            if isinstance(folders, list):
                folders = [
                    folder for folder in folders
                    if isinstance(folder, str) and os.path.isdir(folder)
                ]
                if folders:
                    self._start_scan(folders)

    def import_folder(self):
        if self.scanning:
            self._status("A folder scan is already running.", temporary=True)
            return
        folder = filedialog.askdirectory(
            title="Add a music folder", parent=self.root
        )
        if not folder:
            return

        folders = self.settings.get("libraries", [])
        folders = list(folders) if isinstance(folders, list) else []
        existing = {
            path_key(item) for item in folders if isinstance(item, str)
        }
        if path_key(folder) not in existing:
            folders.append(folder)
        self.settings["libraries"] = folders
        self._schedule_settings_save()
        self._start_scan([folder])

    def rescan_libraries(self):
        if self.scanning:
            self._status("A folder scan is already running.", temporary=True)
            return
        folders = self.settings.get("libraries", [])
        folders = [
            folder for folder in folders
            if isinstance(folder, str)
        ] if isinstance(folders, list) else []
        if not folders:
            self.import_folder()
            return
        self._start_scan(folders)

    # --------------------------------------------------------- URL download

    def add_from_url(self):
        if self.downloading:
            self._status("A download is already running.", temporary=True)
            return
        if self.scanning:
            self._status("A folder scan is already running.", temporary=True)
            return
        url = simpledialog.askstring(
            "Add from URL",
            "Paste a link (YouTube, SoundCloud, Bandcamp, Hype Machine…):",
            parent=self.root,
        )
        if not url:
            return
        url = url.strip()
        if not url.lower().startswith(("http://", "https://")):
            self._status("That does not look like a URL.", error=True,
                         temporary=True)
            return
        self._start_download(url)

    def _start_download(self, url):
        if self.downloading:
            self._status("A download is already running.", temporary=True)
            return
        self.downloading = True
        self._ytdlp_updated = False
        self._last_progress = time.monotonic()
        self._show_download("Connecting…", 0)
        self._status("Downloading…")
        threading.Thread(
            target=self._download_worker, args=(url,),
            daemon=True, name="Download",
        ).start()

    def _download_worker(self, url, attempt=0):
        download_dir = self._download_dir()
        os.makedirs(download_dir, exist_ok=True)
        before = set(os.listdir(download_dir))
        last = {"t": 0.0}

        def progress_hook(d):
            status = d.get("status")
            if status == "downloading":
                total = (
                    d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                )
                downloaded = d.get("downloaded_bytes") or 0
                percent = (downloaded / total * 100) if total else 0.0
                name = os.path.basename(d.get("filename") or "")
                now = time.monotonic()
                if now - last["t"] >= 0.2:
                    last["t"] = now
                    self.events.put(("download_progress", name, percent))
            elif status == "finished":
                self.events.put(("download_progress", "Converting…", 100.0))

        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": os.path.join(download_dir, "%(title)s.%(ext)s"),
            "noplaylist": True,
            "quiet": True,
            "noprogress": True,
            "no_warnings": True,
            "progress_hooks": [progress_hook],
            # YouTube needs a JS runtime to solve its challenges; use Node
            # if it is installed (ignored by yt-dlp otherwise).
            "js_runtimes": {"node": {}, "deno": {}},
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }],
        }
        try:
            import yt_dlp
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])
            new_files = set(os.listdir(download_dir)) - before
            mp3s = [
                os.path.join(download_dir, name)
                for name in new_files if name.lower().endswith(".mp3")
            ]
            if not mp3s:
                mp3s = [
                    os.path.join(download_dir, name)
                    for name in os.listdir(download_dir)
                    if name.lower().endswith(".mp3")
                ]
            if mp3s:
                path = max(mp3s, key=os.path.getmtime)
                self.events.put(("download", path, None))
            else:
                self.events.put(
                    ("download", None, "No MP3 audio file was produced.")
                )
        except Exception as exc:
            if attempt == 0:
                # A stale yt-dlp is the usual cause of failures; refresh it
                # once and retry the download with the new version.
                self.events.put(("download_status", "Updating yt-dlp…"))
                if self._upgrade_ytdlp():
                    self._reload_ytdlp()
                    self.events.put(("download_status", "Retrying…"))
                    self._download_worker(url, attempt=1)
                    return
            self.events.put(("download", None, str(exc)))

    def _upgrade_ytdlp(self):
        """Run ``pip install -U yt-dlp`` and report whether it succeeded."""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-U", "yt-dlp"],
                capture_output=True, text=True, timeout=180,
            )
            ok = result.returncode == 0
        except Exception:
            ok = False
        if ok:
            self._ytdlp_updated = True
        return ok

    def _reload_ytdlp(self):
        """Reload the in-memory yt_dlp modules so a retry uses the new code."""
        import importlib
        for name in list(sys.modules):
            if name == "yt_dlp" or name.startswith("yt_dlp."):
                try:
                    importlib.reload(sys.modules[name])
                except Exception:
                    pass

    def _download_dir(self):
        return os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "downloads"
        )

    def _show_download(self, text="Connecting…", percent=0.0):
        self.download_label.configure(text=text)
        self.download_bar.configure(value=max(0.0, min(100.0, percent)))
        self.download_frame.pack(
            fill="x", padx=20, pady=(0, 6), before=self.footer
        )

    def _update_download_progress(self, name, percent):
        self._show_download(
            f"{name} · {round(percent)}%" if name else f"{round(percent)}%",
            percent,
        )

    def _hide_download(self):
        self.download_frame.pack_forget()

    def _add_downloaded(self, path):
        try:
            track = library.read_meta(path)
        except Exception as exc:
            self._status(f"Could not read downloaded file: {exc}",
                         error=True)
            return
        key = path_key(path)
        if any(path_key(t["path"]) == key for t in self.tracks):
            self._status("That track is already in the playlist.")
            return
        self._push_undo()
        self.tracks.append(track)
        self.sort_column = None
        self._playlist_changed(set())
        self._last_added_title = track["title"]
        self._status(f"Added · {track['title']}")

    def _start_scan(self, folders):
        self.scan_token += 1
        token = self.scan_token
        self.scanning = True
        self._status("Scanning music folders…")

        def work():
            tracks = []
            errors = []
            for folder in folders:
                try:
                    if not os.path.isdir(folder):
                        raise FileNotFoundError(f"Folder not found: {folder}")
                    tracks.extend(library.scan_folder(folder))
                except Exception as exc:
                    errors.append(f"{folder}: {exc}")
            self.events.put(("scan", token, tracks, errors))

        threading.Thread(target=work, daemon=True, name="MusicScan").start()

    def _scan_done(self, token, tracks, errors):
        if token != self.scan_token:
            return
        self.scanning = False
        incoming = self._normalize_tracks(tracks)
        merged = list(self.tracks)
        indices = {
            path_key(track["path"]): index
            for index, track in enumerate(merged)
        }
        added = 0
        updated = 0

        for track in incoming:
            key = path_key(track["path"])
            if key in indices:
                index = indices[key]
                if merged[index] != track:
                    merged[index] = track
                    updated += 1
            else:
                indices[key] = len(merged)
                merged.append(track)
                added += 1

        if added or updated:
            self._push_undo()
            self.tracks = merged
            self.sort_column = None
            self._playlist_changed()

        text = f"Added {added} tracks"
        if updated:
            text += f" · Updated {updated}"
        if errors:
            text += f" · {len(errors)} folder error(s)"
        self._status(text, error=bool(errors))
        if errors:
            messagebox.showwarning(
                "Some folders could not be scanned",
                "\n\n".join(errors[:8]),
                parent=self.root,
            )

    def _cancel_scan(self):
        self.scan_token += 1
        was_scanning = self.scanning
        self.scanning = False
        return was_scanning

    # ------------------------------------------------------- Playlist display

    def _search_changed(self, *args):
        if self.search_job is not None:
            self.root.after_cancel(self.search_job)
        self.search_job = self.root.after(160, self._apply_search)

    def _apply_search(self):
        self.search_job = None
        self._reset_drag()
        self._refresh_tree()

    def _selected_indices(self):
        result = []
        for iid in self.tree.selection():
            try:
                index = int(iid)
                if 0 <= index < len(self.tracks):
                    result.append(index)
            except ValueError:
                pass
        return sorted(result)

    def _selected_paths(self):
        return {
            path_key(self.tracks[index]["path"])
            for index in self._selected_indices()
        }

    def _refresh_tree(self, selected_paths=None):
        if selected_paths is None:
            selected_paths = self._selected_paths()
        old_view = self.tree.yview()
        children = self.tree.get_children()
        if children:
            self.tree.delete(*children)

        words = self.search_var.get().casefold().split()
        self.visible_indices = []
        selected_iids = []

        for index, track in enumerate(self.tracks):
            haystack = (
                f"{track['title']} {track['artist']} "
                f"{os.path.basename(track['path'])}"
            ).casefold()
            if words and not all(word in haystack for word in words):
                continue

            row_number = len(self.visible_indices)
            self.visible_indices.append(index)
            tags = ["odd"] if row_number % 2 else []
            if index == self.current:
                tags.append("playing")
            self.tree.insert(
                "",
                "end",
                iid=str(index),
                values=(
                    self._row_number(index),
                    track["title"],
                    track["artist"],
                    fmt_time(track["duration"]),
                ),
                tags=tags,
            )
            if path_key(track["path"]) in selected_paths:
                selected_iids.append(str(index))

        if selected_iids:
            self.tree.selection_set(selected_iids)
        if old_view:
            self.tree.yview_moveto(old_view[0])

        shown = len(self.visible_indices)
        total = len(self.tracks)
        self.count_label.configure(
            text=f"{shown} / {total}" if words else str(total)
        )
        total_duration = sum(
            self.tracks[index]["duration"] for index in self.visible_indices
        )
        self.duration_label.configure(
            text=f"{fmt_time(total_duration)} total" if shown else ""
        )

        if not shown:
            self.empty_label.configure(
                text=(
                    "No matching tracks.\n\nTry a different search."
                    if total else
                    "Your playlist is empty.\n\nAdd a music folder to get started."
                )
            )
            self.empty_label.place(relx=0.5, rely=0.52, anchor="center")
        else:
            self.empty_label.place_forget()

        labels = {
            "number": "#", "title": "Title",
            "artist": "Artist", "duration": "Time",
        }
        for column, label in labels.items():
            if column == self.sort_column:
                label += " ▾" if self.sort_descending else " ▴"
            self.tree.heading(column, text=label)

    def _mark_current(self, reveal=False):
        for row_number, index in enumerate(self.visible_indices):
            iid = str(index)
            if not self.tree.exists(iid):
                continue
            tags = ["odd"] if row_number % 2 else []
            if index == self.current:
                tags.append("playing")
            self.tree.item(iid, tags=tags)
            self.tree.set(iid, "number", self._row_number(index))
        if reveal and self.tree.exists(str(self.current)):
            self.tree.see(str(self.current))

    def _row_number(self, index):
        if index == self.current:
            return "▶"
        key = path_key(self.tracks[index]["path"])
        if key in self.queue:
            position = self.queue.index(key)
            offset = 2 if self.current >= 0 else 1
            return f"[{position + offset}]"
        return index + 1

    def sort_playlist(self, column):
        if column == "number" or len(self.tracks) < 2:
            return
        selected = self._selected_paths()
        self._push_undo()
        self.sort_descending = (
            not self.sort_descending if self.sort_column == column else False
        )
        self.sort_column = column

        if column == "duration":
            key = lambda track: track["duration"]
        else:
            key = lambda track: track[column].casefold()

        self.tracks.sort(key=key, reverse=self.sort_descending)
        self._playlist_changed(selected)
        self._status("Playlist sorted. Ctrl+Z to undo.", temporary=True)

    def _double_click(self, event):
        if self.tree.identify_region(event.x, event.y) in ("cell", "tree"):
            iid = self.tree.identify_row(event.y)
            if iid:
                self._play_index(int(iid), reset_shuffle=True)
                return "break"
        return None

    def _play_selected_event(self, event):
        self.play_selected()
        return "break"

    def play_selected(self):
        indices = self._selected_indices()
        focus = self.tree.focus()
        if focus and int(focus) in indices:
            index = int(focus)
        elif indices:
            index = indices[0]
        else:
            return
        self._play_index(index, reset_shuffle=True)

    def add_to_queue(self):
        indices = self._selected_indices()
        if not indices:
            return
        current_key = (
            path_key(self.current_path) if self.current_path else None
        )
        added = 0
        for index in indices:
            key = path_key(self.tracks[index]["path"])
            if key == current_key or key in self.queue:
                continue
            self.queue.append(key)
            added += 1
        if added:
            self._refresh_tree()
            self._status(f"Added {added} track(s) to queue.")
        else:
            self._status("Selected tracks are already in the queue.")

    def select_all(self):
        self.tree.selection_set(self.tree.get_children())

    def _context_menu(self, event):
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        if iid not in self.tree.selection():
            self.tree.selection_set(iid)
        self.tree.focus(iid)
        self.tree.focus_set()
        try:
            self.context.tk_popup(event.x_root, event.y_root)
        finally:
            self.context.grab_release()

    def _first_selected_path(self):
        indices = self._selected_indices()
        if indices:
            return self.tracks[indices[0]]["path"]
        return None

    def copy_selected_path(self):
        path = self._first_selected_path()
        if path:
            self.root.clipboard_clear()
            self.root.clipboard_append(path)
            self._status("File path copied.", temporary=True)

    def edit_track(self):
        indices = self._selected_indices()
        if not indices:
            return
        focus = self.tree.focus()
        if focus and focus.isdigit() and int(focus) in indices:
            index = int(focus)
        else:
            index = indices[0]
        track = self.tracks[index]

        dialog = tk.Toplevel(self.root)
        dialog.title("Edit track details")
        dialog.configure(bg=BG)
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.grab_set()

        title_var = tk.StringVar(value=track["title"])
        artist_var = tk.StringVar(value=track["artist"])
        album_var = tk.StringVar(value=track.get("album", ""))

        fields = (
            ("Title", title_var),
            ("Artist", artist_var),
            ("Album", album_var),
        )
        for row, (label, var) in enumerate(fields):
            tk.Label(
                dialog, text=label, bg=BG, fg=MUTED,
                font=(FONT, 9), anchor="w",
            ).grid(row=row, column=0, sticky="w", padx=18, pady=(12, 0))
            tk.Entry(
                dialog, textvariable=var, bg=CARD2, fg=TEXT,
                insertbackground=ACCENT, relief="flat", bd=0,
                font=(FONT, 10), width=38,
            ).grid(row=row, column=1, sticky="we", padx=(6, 18), pady=(12, 0))

        def save(event=None):
            title = title_var.get().strip() or os.path.splitext(
                os.path.basename(track["path"])
            )[0]
            artist = artist_var.get().strip() or "Unknown Artist"
            album = album_var.get().strip()
            try:
                library.write_meta(track["path"], title, artist, album)
            except Exception as exc:
                messagebox.showerror(
                    "Could not save tags", str(exc), parent=dialog
                )
                return
            self.tracks[index]["title"] = title
            self.tracks[index]["artist"] = artist
            self.tracks[index]["album"] = album
            self._refresh_tree()
            self._redraw()
            self._status(f"Updated · {title}")
            dialog.destroy()

        buttons = tk.Frame(dialog, bg=BG)
        buttons.grid(row=len(fields), column=0, columnspan=2,
                     sticky="e", padx=18, pady=14)
        tk.Button(
            buttons, text="Save", command=save,
            bg=ACCENT, fg="#0a1220", activebackground="#7fe7f5",
            activeforeground="#0a1220", relief="flat", bd=0,
            padx=16, pady=5, font=(FONT, 9, "bold"), cursor="hand2",
        ).pack(side="left", padx=(0, 8))
        tk.Button(
            buttons, text="Cancel", command=dialog.destroy,
            bg=CARD2, fg=TEXT, activebackground=CARD3,
            activeforeground=TEXT, relief="flat", bd=0,
            padx=16, pady=5, font=(FONT, 9), cursor="hand2",
        ).pack(side="left")

        dialog.bind("<Return>", save)
        dialog.bind("<Escape>", lambda event: dialog.destroy())

        dialog.update_idletasks()
        width = dialog.winfo_reqwidth()
        height = dialog.winfo_reqheight()
        x = self.root.winfo_rootx() + (
            self.root.winfo_width() - width
        ) // 2
        y = self.root.winfo_rooty() + (
            self.root.winfo_height() - height
        ) // 2
        dialog.geometry(f"+{max(0, x)}+{max(0, y)}")

    def reveal_selected(self):
        path = self._first_selected_path()
        if not path:
            return
        folder = os.path.dirname(path)
        try:
            if sys.platform == "win32":
                os.startfile(folder)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", folder])
            else:
                subprocess.Popen(["xdg-open", folder])
        except Exception as exc:
            messagebox.showerror(
                "Could not open folder", str(exc), parent=self.root
            )

    # ------------------------------------------------------ Selection / drag

    def _tree_press(self, event):
        self._reset_drag()
        if self.tree.identify_region(event.x, event.y) not in ("cell", "tree"):
            return None

        iid = self.tree.identify_row(event.y)
        if not iid:
            return None

        self.tree.focus_set()
        self.tree.focus(iid)
        index = int(iid)
        control = bool(event.state & 0x0004)
        shift = bool(event.state & 0x0001)

        if shift and self.selection_anchor in self.visible_indices:
            start = self.visible_indices.index(self.selection_anchor)
            end = self.visible_indices.index(index)
            selected = [
                str(value) for value in self.visible_indices[
                    min(start, end):max(start, end) + 1
                ]
            ]
            if control:
                self.tree.selection_add(selected)
            else:
                self.tree.selection_set(selected)
        elif control:
            if iid in self.tree.selection():
                self.tree.selection_remove(iid)
            else:
                self.tree.selection_add(iid)
            self.selection_anchor = index
        elif iid in self.tree.selection():
            # Preserve a multi-selection until we know whether this is a drag.
            self.collapse_selection = iid
            self.selection_anchor = index
        else:
            self.tree.selection_set(iid)
            self.selection_anchor = index

        if iid in self.tree.selection() and not control and not shift:
            self.drag_index = index
            self.drag_start_y = event.y
        return "break"

    def _tree_motion(self, event):
        if self.drag_index is None:
            return "break"
        if self.search_var.get().strip():
            if abs(event.y - self.drag_start_y) > 6:
                self.collapse_selection = None
                self._status(
                    "Clear search before reordering tracks.", temporary=True
                )
            return "break"

        if not self.dragging and abs(event.y - self.drag_start_y) > 6:
            self.dragging = True
            self.collapse_selection = None
            self.drag_indices = self._selected_indices()
            self.tree.configure(cursor="fleur")

        if self.dragging:
            if event.y < 35:
                self.tree.yview_scroll(-1, "units")
            elif event.y > self.tree.winfo_height() - 20:
                self.tree.yview_scroll(1, "units")
            self._show_drop_line(event.y)
        return "break"

    def _drop_target(self, y):
        iid = self.tree.identify_row(y)
        if iid:
            box = self.tree.bbox(iid)
            if box:
                return int(iid) + (1 if y > box[1] + box[3] / 2 else 0)

        # Dropping into the heading area means before the first visible row.
        for index in self.visible_indices:
            box = self.tree.bbox(str(index))
            if box:
                if y < box[1]:
                    return index
                break
        return len(self.tracks)

    def _show_drop_line(self, y):
        iid = self.tree.identify_row(y)
        if iid:
            box = self.tree.bbox(iid)
            if box:
                y = box[1] + (box[3] if y > box[1] + box[3] / 2 else 0)
        y = clamp(y, 28, max(28, self.tree.winfo_height() - 3))
        self.drop_line.place(
            x=self.tree.winfo_x(),
            y=self.tree.winfo_y() + y,
            width=self.tree.winfo_width(),
            height=3,
        )
        self.drop_line.lift()

    def _tree_release(self, event):
        handled = self.drag_index is not None or self.dragging
        if self.dragging and self.drag_indices:
            target = self._drop_target(event.y)
            self._reorder(self.drag_indices, target)
        elif self.collapse_selection and self.tree.exists(self.collapse_selection):
            self.tree.selection_set(self.collapse_selection)
        self._reset_drag()
        return "break" if handled else None

    def _reset_drag(self):
        self.drag_index = None
        self.drag_indices = []
        self.dragging = False
        self.collapse_selection = None
        if hasattr(self, "tree"):
            self.tree.configure(cursor="")
        if hasattr(self, "drop_line"):
            self.drop_line.place_forget()

    def _reorder(self, indices, target):
        source = set(indices)
        block = [track for i, track in enumerate(self.tracks) if i in source]
        remaining = [track for i, track in enumerate(self.tracks) if i not in source]
        insert_at = target - sum(index < target for index in source)
        insert_at = int(clamp(insert_at, 0, len(remaining)))
        reordered = remaining[:insert_at] + block + remaining[insert_at:]

        if reordered == self.tracks:
            return
        selected = {path_key(track["path"]) for track in block}
        self._push_undo()
        self.tracks = reordered
        self.sort_column = None
        self._playlist_changed(selected)
        self._status("Tracks moved. Ctrl+Z to undo.", temporary=True)

    # ----------------------------------------------------- Playlist mutation

    def _push_undo(self):
        self.undo_stack.append([dict(track) for track in self.tracks])
        if len(self.undo_stack) > MAX_UNDO:
            del self.undo_stack[0]

    def undo(self):
        if self.scanning:
            self._cancel_scan()
            self._status("Pending import cancelled.", temporary=True)
            return
        if not self.undo_stack:
            self._status("Nothing to undo.", temporary=True)
            return
        self.tracks = self.undo_stack.pop()
        self.sort_column = None
        self._playlist_changed(set())
        self._status("Playlist change undone.", temporary=True)

    def clear_playlist(self):
        if not self.tracks and not self.scanning:
            return
        if not messagebox.askyesno(
            "Clear playlist",
            "Remove all tracks from the playlist?\n\n"
            "Your music files will not be deleted. You can undo this change.",
            parent=self.root,
        ):
            return
        self._cancel_scan()
        if self.tracks:
            self._push_undo()
        self.stop_play()
        self.tracks = []
        self.sort_column = None
        self._playlist_changed(set())
        self._status("Playlist cleared. Ctrl+Z to undo.", temporary=True)

    def remove_selected(self):
        selected = set(self._selected_indices())
        if not selected:
            return
        self._push_undo()
        self.tracks = [
            track for index, track in enumerate(self.tracks)
            if index not in selected
        ]
        self._playlist_changed(set())
        self._status(
            f"Removed {len(selected)} tracks. Ctrl+Z to undo.",
            temporary=True,
        )

    def _playlist_changed(self, selected_paths=None):
        self._reset_drag()
        self.selection_anchor = None
        self._prune_queue()
        self._sync_current()
        self._reset_shuffle_bag()
        self._refresh_tree(selected_paths or set())
        self._redraw()
        self._save_playlist()

    def _prune_queue(self):
        valid = {path_key(track["path"]) for track in self.tracks}
        self.queue = [key for key in self.queue if key in valid]

    def _sync_current(self):
        if self.current_path is None:
            self.current = -1
            return
        key = path_key(self.current_path)
        self.current = next(
            (
                index for index, track in enumerate(self.tracks)
                if path_key(track["path"]) == key
            ),
            -1,
        )
        if self.current < 0:
            self.stop_play()

    # -------------------------------------------------------------- Playback

    def _current_track(self):
        if 0 <= self.current < len(self.tracks):
            return self.tracks[self.current]
        return None

    def _position(self):
        try:
            return max(0.0, number(self.player.position))
        except Exception:
            return 0.0

    def _duration(self):
        track = self._current_track()
        if not track:
            return 0.0
        duration = number(track.get("duration"))
        if duration <= 0:
            try:
                duration = number(getattr(self.player, "duration", 0))
            except Exception:
                duration = 0.0
        return max(0.0, duration)

    # ------------------------------------------------------------- Resume

    def _save_resume(self):
        self.last_resume_save = time.monotonic()
        self.settings["resume_path"] = self.current_path
        self.settings["resume_pos"] = (
            float(self._position()) if self.current_path else 0.0
        )
        self._write(settings_mod.save_settings, self.settings, "settings")

    def _resume_at(self, index, position):
        if not 0 <= index < len(self.tracks):
            return
        track = self.tracks[index]
        if not os.path.isfile(track["path"]):
            return
        self.play_token += 1
        token = self.play_token
        self.seek_dragging = False
        self.current = index
        self.current_path = track["path"]
        try:
            self.player.on_track_end = None
            self.player.stop()
            self.player.on_track_end = (
                lambda generation=token:
                self.events.put(("ended", generation))
            )
            self.player.set_volume(0.0 if self.muted else self.volume)
            self.player.load(track["path"])
            if position > 0:
                duration = self._duration()
                if duration > 0:
                    self.player.seek(
                        min(position, max(0.0, duration - 0.05))
                    )
            self.player.pause()
        except Exception as exc:
            self._status(f"Could not resume playback: {exc}", error=True)
            return
        self.seek_fraction = 0.0
        self.listen_clock = time.monotonic()
        self.listen_active = False
        key = path_key(track["path"])
        if key in self.queue:
            self.queue.remove(key)
        self._load_art_async(track["path"])
        self._mark_current(reveal=True)
        self._redraw()

    def _restore_resume(self):
        path = self.settings.get("resume_path")
        position = number(self.settings.get("resume_pos"))
        if not path or position <= 0:
            return
        index = self._index_for_key(path_key(path))
        if index < 0:
            return
        self._resume_at(index, position)
        self._status(f"Resumed at {fmt_time(position)}")

    def _play_index(self, index, reset_shuffle=False, add_history=True):
        if not 0 <= index < len(self.tracks):
            return
        track = self.tracks[index]
        if not os.path.isfile(track["path"]):
            self._status("The selected music file is missing.", error=True)
            messagebox.showerror(
                "File not found",
                f"The file may have been moved or deleted:\n\n{track['path']}",
                parent=self.root,
            )
            return

        self._account_listening()
        self.play_token += 1
        token = self.play_token
        self.seek_dragging = False

        try:
            # Remove the old callback while replacing the current decoder.
            self.player.on_track_end = None
            self.player.stop()
            self.player.on_track_end = (
                lambda generation=token:
                self.events.put(("ended", generation))
            )
            self.player.set_volume(0.0 if self.muted else self.volume)
            self.player.load(track["path"])
        except Exception as exc:
            self.stop_play()
            messagebox.showerror(
                "Playback error",
                f"Could not play {track['title']}:\n\n{exc}",
                parent=self.root,
            )
            return

        self.current = index
        self.current_path = track["path"]
        self.seek_fraction = 0.0
        self.listen_clock = time.monotonic()
        self.listen_active = bool(self.player.is_playing)

        if reset_shuffle:
            self._reset_shuffle_bag()
        key = path_key(track["path"])
        if key in self.queue:
            self.queue.remove(key)
        self.shuffle_bag = [item for item in self.shuffle_bag if item != key]

        if add_history:
            self.history = self.history[:self.history_position + 1]
            self.history.append(key)
            self.history = self.history[-500:]
            self.history_position = len(self.history) - 1

        entry = self.stats.setdefault(
            track["path"],
            {
                "title": track["title"],
                "artist": track["artist"],
                "count": 0,
                "time": 0.0,
            },
        )
        entry["title"] = track["title"]
        entry["artist"] = track["artist"]
        entry["count"] += 1
        self.stats_dirty = True

        self._load_art_async(track["path"])
        self._mark_current(reveal=True)
        self._redraw()
        self._status(f"Playing · {track['title']}")

    def toggle_play(self):
        if self.current < 0:
            selected = self._selected_indices()
            if selected:
                self._play_index(selected[0], reset_shuffle=True)
            elif self.tracks:
                index = random.randrange(len(self.tracks)) if self.shuffle else 0
                self._play_index(index, reset_shuffle=True)
            return

        self._account_listening()
        try:
            if self.player.is_playing:
                self.player.pause()
                self._status("Paused")
            else:
                self.player.play()
                self._status(f"Playing · {self._current_track()['title']}")
        except Exception as exc:
            messagebox.showerror(
                "Playback error", str(exc), parent=self.root
            )
        self.listen_clock = time.monotonic()
        self.listen_active = bool(self.player.is_playing)
        self._redraw()

    def stop_play(self):
        self._account_listening()
        self.play_token += 1
        self.player.on_track_end = None
        try:
            self.player.stop()
        except Exception as exc:
            self._status(f"Could not stop playback: {exc}", error=True)
        self.current = -1
        self.current_path = None
        self.seek_dragging = False
        self.seek_fraction = 0.0
        self.listen_active = False
        self.art_token += 1
        self._clear_art()
        self._mark_current()
        self._redraw()

    def seek_to(self, position):
        if self.current < 0 or not self.player.loaded:
            return
        duration = self._duration()
        if duration <= 0:
            return
        self._account_listening()
        # Seeking does not call play(): paused playback remains paused.
        try:
            self.player.seek(clamp(position, 0.0, max(0.0, duration - 0.05)))
        except Exception as exc:
            self._status(f"Seek failed: {exc}", error=True)
        self.listen_clock = time.monotonic()
        self.listen_active = bool(self.player.is_playing)
        self._update_progress()

    def seek_relative(self, seconds):
        self.seek_to(self._position() + seconds)

    def next_track(self):
        self._advance(auto=False)

    def previous_track(self):
        if not self.tracks:
            return
        if self.current >= 0 and self._position() > 3:
            self.seek_to(0)
            return

        if self.shuffle:
            while self.history_position > 0:
                self.history_position -= 1
                key = self.history[self.history_position]
                index = self._index_for_key(key)
                if index >= 0:
                    self._play_index(index, add_history=False)
                    return

        index = self.current - 1 if self.current >= 0 else len(self.tracks) - 1
        self._play_index(index % len(self.tracks))

    def _advance(self, auto=False):
        if not self.tracks:
            return
        if auto and self.current < 0:
            return
        if auto and self.repeat == "one":
            self._play_index(self.current)
            return

        while self.queue:
            key = self.queue.pop(0)
            index = self._index_for_key(key)
            if index >= 0:
                self._play_index(index)
                return

        if self.shuffle:
            # After using Previous, Next follows existing history first.
            if not auto:
                while self.history_position + 1 < len(self.history):
                    self.history_position += 1
                    index = self._index_for_key(self.history[self.history_position])
                    if index >= 0:
                        self._play_index(index, add_history=False)
                        return

            while self.shuffle_bag:
                key = self.shuffle_bag.pop()
                index = self._index_for_key(key)
                if index >= 0:
                    self._play_index(index)
                    return

            if auto and self.repeat != "all":
                self.stop_play()
                self._status("Playlist finished.")
                return

            self._reset_shuffle_bag()
            if self.shuffle_bag:
                self._play_index(self._index_for_key(self.shuffle_bag.pop()))
            elif self.tracks:
                self._play_index(0)
            return

        index = self.current + 1
        if index >= len(self.tracks):
            if auto and self.repeat != "all":
                self.stop_play()
                self._status("Playlist finished.")
                return
            index = 0
        self._play_index(index)

    def _index_for_key(self, key):
        return next(
            (
                index for index, track in enumerate(self.tracks)
                if path_key(track["path"]) == key
            ),
            -1,
        )

    def _reset_shuffle_bag(self):
        current_key = path_key(self.current_path) if self.current_path else None
        self.shuffle_bag = [
            path_key(track["path"]) for track in self.tracks
            if path_key(track["path"]) != current_key
        ]
        random.shuffle(self.shuffle_bag)

    def toggle_shuffle(self):
        self.shuffle = not self.shuffle
        self._reset_shuffle_bag()
        self._redraw()
        self._schedule_settings_save()
        self._status(
            "Shuffle enabled" if self.shuffle else "Shuffle disabled",
            temporary=True,
        )

    def toggle_repeat(self):
        modes = ("off", "all", "one")
        self.repeat = modes[(modes.index(self.repeat) + 1) % len(modes)]
        self._redraw()
        self._schedule_settings_save()

    def set_volume(self, volume):
        was_muted = self.muted
        was_zero = self.volume == 0
        self.volume = clamp(number(volume))
        self.muted = False
        self.player.set_volume(self.volume)
        if was_muted or was_zero != (self.volume == 0):
            self._redraw()
        else:
            self._update_volume()
        self._schedule_settings_save()

    def toggle_mute(self):
        self.muted = not self.muted
        self.player.set_volume(0.0 if self.muted else self.volume)
        self._redraw()
        self._schedule_settings_save()

    # --------------------------------------------------------------- Artwork

    def _clear_art(self):
        self.art_image = None
        self.art_photo = None
        self.art_photo_size = None

    def _load_art_async(self, path):
        self.art_token += 1
        token = self.art_token
        self._clear_art()

        def work():
            image = None
            try:
                data = library.read_art(path)
                if data:
                    with Image.open(io.BytesIO(data)) as source:
                        source.thumbnail((512, 512))
                        image = source.convert("RGB").copy()
            except Exception:
                # Broken artwork should never stop music playback.
                image = None
            self.events.put(("art", token, image))

        threading.Thread(target=work, daemon=True, name="AlbumArt").start()

    # --------------------------------------------------------------- Polling

    def _poll(self):
        self.poll_job = None
        if self._closed:
            return

        # Limit work per tick so a burst of results cannot starve the UI.
        for _ in range(40):
            try:
                event = self.events.get_nowait()
            except queue.Empty:
                break

            kind = event[0]
            if kind == "scan":
                self._scan_done(*event[1:])
            elif kind == "art":
                _, token, image = event
                if token == self.art_token:
                    self.art_image = image
                    self.art_photo = None
                    self.art_photo_size = None
                    self._redraw()
            elif kind == "ended":
                _, token = event
                if token == self.play_token and self.current >= 0:
                    self._advance(auto=True)
            elif kind == "media":
                self._handle_media_key(event[1])
            elif kind == "download_progress":
                self._update_download_progress(event[1], event[2])
            elif kind == "download_status":
                self._show_download(event[1], 0)
            elif kind == "download":
                path, error = event[1], event[2]
                self._hide_download()
                self.downloading = False
                if error:
                    self._status(f"Download failed: {error}", error=True)
                    messagebox.showerror(
                        "Download failed", error, parent=self.root
                    )
                else:
                    self._add_downloaded(path)
                    if self._ytdlp_updated:
                        self._ytdlp_updated = False
                        self._status(
                            "yt-dlp updated · "
                            f"Added {self._last_added_title}"
                        )

        self._account_listening()
        playing = bool(self.player.is_playing)
        if playing != self.last_playing_state:
            self._redraw()
        else:
            self._update_progress()

        now = time.monotonic()
        if self.stats_dirty and now - self.last_stats_save >= 15:
            self._save_stats()
        if self.current_path and now - self.last_resume_save >= 15:
            self._save_resume()

        if not self._closed:
            self.poll_job = self.root.after(POLL_MS, self._poll)

    # ------------------------------------------------------------ Statistics

    def _account_listening(self):
        now = time.monotonic()
        elapsed = now - self.listen_clock
        self.listen_clock = now

        # Count wall-clock listening time, not playback-position changes.
        # This prevents forward seeks from being counted as listening.
        # Long UI stalls/system sleep are deliberately not counted.
        if (
            self.current_path
            and self.listen_active
            and 0 < elapsed <= 2.0
        ):
            entry = self.stats.get(self.current_path)
            if entry is not None:
                entry["time"] += elapsed
                self.stats_dirty = True

        self.listen_active = (
            self.current_path is not None and bool(self.player.is_playing)
        )

    def _save_stats(self):
        self.last_stats_save = time.monotonic()
        if self._write(settings_mod.save_stats, self.stats, "statistics"):
            self.stats_dirty = False

    def show_statistics(self):
        self._account_listening()
        self._save_stats()

        top = tk.Toplevel(self.root)
        top.title("DeepSound · Listening statistics")
        top.configure(bg=BG)
        top.geometry("720x480")
        top.minsize(520, 320)
        top.transient(self.root)

        total_plays = sum(entry["count"] for entry in self.stats.values())
        total_time = sum(entry["time"] for entry in self.stats.values())

        tk.Label(
            top,
            text="Your listening history",
            bg=BG, fg=TEXT, font=(FONT, 16, "bold"),
        ).pack(anchor="w", padx=18, pady=(18, 5))

        tk.Label(
            top,
            text=f"{total_plays:,} plays  ·  {fmt_time(total_time)} listened  ·  "
                 f"{len(self.stats):,} tracks",
            bg=BG, fg=MUTED, font=(FONT, 10),
        ).pack(anchor="w", padx=18, pady=(0, 15))

        frame = tk.Frame(top, bg=TRACK)
        frame.pack(fill="both", expand=True, padx=18, pady=(0, 18))

        tree = ttk.Treeview(
            frame,
            columns=("title", "artist", "count", "time"),
            show="headings",
            style="Music.Treeview",
        )
        bar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        tree.pack(side="left", fill="both", expand=True)

        rows = [dict(entry) for entry in self.stats.values()]
        ordering = {"column": "count", "reverse": True}

        def populate(column=None):
            if column is not None:
                ordering["reverse"] = (
                    not ordering["reverse"]
                    if ordering["column"] == column
                    else column in ("count", "time")
                )
                ordering["column"] = column

            column = ordering["column"]
            key = (
                (lambda row: row[column].casefold())
                if column in ("title", "artist")
                else (lambda row: row[column])
            )
            children = tree.get_children()
            if children:
                tree.delete(*children)

            for entry in sorted(rows, key=key, reverse=ordering["reverse"]):
                tree.insert(
                    "", "end",
                    values=(
                        entry["title"],
                        entry["artist"],
                        entry["count"],
                        fmt_time(entry["time"]),
                    ),
                )

        for column, label, width in (
            ("title", "Title", 270),
            ("artist", "Artist", 180),
            ("count", "Plays", 70),
            ("time", "Listened", 100),
        ):
            tree.heading(
                column, text=label,
                command=lambda name=column: populate(name),
            )
            tree.column(
                column,
                width=width,
                minwidth=60,
                anchor="w" if column in ("title", "artist") else "e",
            )

        populate()
        top.bind("<Escape>", lambda event: top.destroy())

    # ---------------------------------------------------------- Persistence

    def _write(self, function, data, description):
        try:
            function(data)
            return True
        except Exception as exc:
            self._status(f"Could not save {description}: {exc}", error=True)
            return False

    def _save_playlist(self):
        if self._write(settings_mod.save_playlist, self.tracks, "playlist"):
            self.settings["playlist_initialized"] = True
            self._schedule_settings_save()

    def _schedule_settings_save(self):
        if self._closed:
            return
        if self.settings_job is not None:
            self.root.after_cancel(self.settings_job)
        self.settings_job = self.root.after(750, self._save_settings)

    def _save_settings(self):
        self.settings_job = None
        self.settings.update(
            {
                "volume": self.volume,
                "muted": self.muted,
                "shuffle": self.shuffle,
                "repeat": self.repeat,
                "geometry": (
                    f"{self.root.winfo_width()}x{self.root.winfo_height()}"
                ),
                "resume_path": self.current_path,
                "resume_pos": (
                    float(self._position()) if self.current_path else 0.0
                ),
            }
        )
        self._write(settings_mod.save_settings, self.settings, "settings")

    # -------------------------------------------------------------- Shutdown

    def on_close(self):
        if self._closed:
            return

        self._account_listening()
        self.tooltip.hide()
        if self.media_keys is not None:
            self.media_keys.stop()
        self._cancel_scan()
        self.art_token += 1
        self.play_token += 1

        for job in (
            self.poll_job,
            self.search_job,
            self.settings_job,
            self.redraw_job,
            self.status_job,
        ):
            if job is not None:
                try:
                    self.root.after_cancel(job)
                except tk.TclError:
                    pass

        # Save explicitly without scheduling more delayed callbacks.
        if self._write(settings_mod.save_playlist, self.tracks, "playlist"):
            self.settings["playlist_initialized"] = True
        self._save_settings()
        self._save_stats()

        self._closed = True
        self.player.on_track_end = None
        try:
            self.player.close()
        except Exception:
            pass
        finally:
            self.root.destroy()


def main():
    if sys.platform == "win32":
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "DeepSound.DeepSound"
            )
        except Exception:
            pass

        # Avoid a blurry interface on high-DPI Windows displays.
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass

    if icon is not None:
        try:
            icon.ensure_fresh()
        except Exception:
            pass

    root = tk.Tk()
    try:
        app = App(root)
    except Exception as exc:
        messagebox.showerror(
            "DeepSound could not start",
            f"{exc}\n\nCheck your audio device and installed dependencies.",
            parent=root,
        )
        root.destroy()
        return

    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
