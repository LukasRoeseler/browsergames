# DeepSound

A lightweight, native Windows music player that plays your local audio files.
It is built to run quietly in the background with very low resource use.

Current version: **v0.1**

## What it does

- Plays MP3, FLAC, OGG, M4A, WAV, AAC, Opus and more.
- Modern mobile-style interface: a canvas-drawn player card with album art on
  the left, title/artist on the right, a custom seek bar, round transport
  buttons and volume, above a dark playlist.
- Repeat modes: **none / all / one** (the `↻` button shows a small `1` when
  set to repeat-one).
- Streams audio on the fly (does **not** load a whole song into memory), so it
  stays light even for long tracks / audiobooks.
- Imports a music folder and remembers your playlist between runs.
- Hover tooltips on every button.
- Statistics: how often each song is played and total time listened
  (Options menu → Statistics).
- Minimize it and keep listening — it keeps playing in the background, and the
  taskbar shows the DeepSound logo.

## How to run

Double-click **`Start DeepSound.vbs`** — this launches the player with no
console window (runs in the background).

Alternatively, use **`Start DeepSound.bat`** (still no window, easy to edit),
or run from a terminal:

```
py -3.12 "C:\Users\lroesele.IVV5NET\Claude_Code\aimp_clone\aimp.py"
```

### Desktop shortcut with the logo

Run **`Create DeepSound Shortcut.vbs`** once to add a **DeepSound** shortcut to
your desktop. It launches the app and uses the DeepSound logo (`app.ico`).

On first start it automatically scans the music library at
`Claude_Code\youtube-mp3\downloads`. Use the Options menu (☰) → **Import
Folder** to add more.

## Controls

| Action | How |
| --- | --- |
| Play / Pause | `Space` or the round play button |
| Next / Previous | `Ctrl+Right` / `Ctrl+Left` or the round buttons |
| Seek | drag the progress bar |
| Volume | drag the volume bar or `Ctrl+Up` / `Ctrl+Down` |
| Shuffle / Repeat | click the `⇄` / `↻` round toggles |
| Options menu (import, clear, undo, stats) | the `☰` button |
| Play a song | double-click it in the list |
| Select several songs | `Ctrl+click` / `Shift+click` |
| Reorder songs | drag one (or several selected) rows to a new spot |
| Remove selected | `Delete` |
| Undo last action(s) | `Ctrl+Z` (or the Undo option) |

## Files

- `aimp.py` — the GUI application (run this).
- `player.py` — streaming audio engine (PyAV decode + sounddevice output).
- `library.py` — metadata / album-art reading (mutagen).
- `settings.py` — saves volume, shuffle/repeat, library folders and stats.
- `icon.py` — generates the app icon; the app rebuilds it on startup if the
  design source changes, so the desktop shortcut logo stays up to date.
- `icon.png`, `app.ico`, `icon.svg` — the app icon (window, taskbar, shortcut).
- `playlist.json` / `settings.json` / `stats.json` — your saved data (created automatically).

## Requirements

Already installed on this machine (Python 3.12): `av`, `sounddevice`,
`numpy`, `mutagen`, `pillow` (tkinter ships with Python).
